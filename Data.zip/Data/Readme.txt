This folder contains the initial data adopted and generated in our study, including:
The table"Liner companies" Including the companies from which data was collected in the manuscript.
The script "finaltable1_L_noweight" includes the topological network data for SPACE L's container shipping network.
The script "finaltable1_L_weight" includes the capacity-weighted network data for SPACE L's container shipping network.
The script "finaltable1_P_noweight"  includes the topological network data for SPACE P's container shipping network.